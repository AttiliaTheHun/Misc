<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<!-- Begin navigation elements for sub-page -->
<head>

	<title>GDIAC News</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link rel='shortcut icon' href='../images/favicon.ico' type='image/x-icon' />
	<link rel='stylesheet' type='text/css' href='../css/style.css'   />
	<link rel='stylesheet' type='text/css' href='../css/superfish-topmenu.css' media='screen' />
	<link rel='stylesheet' type='text/css' href='../css/superfish-sidebar.css' media='screen' />
	<link rel='stylesheet' type='text/css' href='../js/ts-themes/blue/style.css' media='screen' />
	<script type='text/javascript' src='../js/jquery-1.11.1.min.js'></script>
	<script type='text/javascript' src='http://code.jquery.com/jquery-migrate-1.2.1.js'></script>
	<script type='text/javascript' src='../js/jquery.bgiframe.3.min.js'></script>
	<script type='text/javascript' src='../js/jquery.tablesorter.js'></script>
	<script type='text/javascript' src='../js/hoverIntent.js'></script>
	<script type='text/javascript' src='../js/superfish-1.7.4.js'></script>
    <script type='text/javascript'>
        $(document).ready(function () {
            $('ul.sf-menu').superfish({
                speed: 200                          // faster animation speed 
            }).find('ul').bgIframe({ opacity: false });

            $('ul.sf-menuv').superfish({
                speed: 200                          // faster animation speed 
            }).find('ul').bgIframe({ opacity: false });
        }); 
    </script>
</head>
<body>
<div id="wrap">
	<!-- Start of Open Bracket for Navigation -->
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr><td>
				<!-- Begin unit for GDIAC Banner -->
			<div id="cu-identity">
				<div id="cu-logo">
					<a id="insignia-link" href="http://www.cornell.edu/">
					<img src="../images/banner/gdiac_signature_unstyled.gif" alt="Cornell University" width="342" height="75" border="0" />					</a>
					<div id="unit-signature-links">
						<a id="cornell-link" href="http://www.cornell.edu/">Cornell University</a>
						<a id="unit-link" href="http://gdiac.cis.cornell.edu">The Game Design Initiative</a>
					</div>
				</div>
				<!-- 
					The search-form div contains a form that allows the user to search 
					either the unit website or all of cornell.edu directly from the banner.
				-->
				<div id="search-form">
					<form action="#" method="post" enctype="application/x-www-form-urlencoded">
						<div id="search-input">
							<label for="search-form-query">SEARCH:</label>
							<input type="text" id="search-form-query" name="query" value="" size="20" />
							<input type="submit" id="search-form-submit" name="submit" value="go" />
						</div>
						<div id="search-filters">
							<input type="radio" id="search-filters1" name="target" value="unit" checked="checked" />
							<label for="search-filters1">GDIAC</label>
							<input type="radio" id="search-filters2" name="target" value="cornell" />
							<label for="search-filters2">Cornell</label>
						</div>	
					</form>
				</div>
			</div>
			
			<!-- macros needed for all pages -->
				<!-- End unit for GDIAC Banner -->
			</td></tr>
            <tr><td>
				<ul class='sf-menu'>

					<li><a class='leftmost' href="../about/contact.php">ABOUT</a>
						<ul>
						<li class ="first" ><a href="../about/contact.php">Contact Information</a></li>
						<li class ="last" ><a href="../about/history.php">History & Mission</a></li>
						</ul>
					</li>
					<li><a class='interior' href="../information/prospective.php">INFORMATION</a>
						<ul>
						<li class ="first" ><a href="../information/prospective.php">for Prospective Students</a></li>
						<li><a href="../information/undergraduate.php">for Undergraduates</a></li>
						<li><a href="../information/graduate.php">for Graduate Students</a></li>
						<li><a href="../information/faculty.php">for Faculty</a></li>
						<li><a href="../information/community.php">for Ithaca Community</a></li>
						<li><a href="../information/alumni.php">for Cornell Alumni</a></li>
						<li class ="last" ><a href="../information/press-media.php">for Press & Media</a></li>
						</ul>
					</li>
					<li><a class='interior' href="../programs/minor.php">PROGRAMS</a>
						<ul>
						<li class ="first" ><a href="../programs/minor.php">Game Design Minor</a></li>
						<li><a href="../programs/research.php">Graduate Research</a></li>
						<li class ="last" ><a href="../programs/outreach.php">Outreach Program</a></li>
						</ul>
					</li>
					<li><a class='interior' href="../courses/gdiac-courses.php">COURSES</a>
						<ul>
						<li class ="first" ><a href="../courses/gdiac-courses.php">GDIAC Courses</a></li>
						<li><a href="../courses/other-courses.php">Affiliated Courses</a></li>
						<li><a href="../courses/independent-study.php">Independent Study</a></li>
						<li class ="last" ><a href="../courses/showcase.php">Games Showcase</a></li>
						</ul>
					</li>
					<li><a class='interior' href="../resources/partners.php">RESOURCES</a>
						<ul>
						<li class ="first" ><a href="../resources/partners.php">GDIAC Partners</a></li>
						<li class ="last" ><a href="../resources/gamex.php">GameX Archive</a></li>
						</ul>
					</li>
					<li><a class='interior' href="../people/index.php">PEOPLE</a></li>
					<li><a class='interior' href="../gallery/index.php">GALLERY</a></li>
					<li class="current" ><a class='rightmost' href="../news/index.php">NEWS</a></li>
				</ul>
            </td></tr>
			<tr><td>
				<img src='../images/space.gif' width='1' height='12'>			</td></tr>
            <tr><td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border-bottom: solid 1px #bbbbbb; border-collapse: collapse;">
					<tr>
					<td valign="top">
						<div id="content">
							<div class="small">
								You are here:
								<a href='../index.php'>GDIAC Home</a> &raquo; <a href="../news/index.php">News</a>							</div>
							<p class="title">GDIAC News</p>
<!-- End of Open Bracket for Navigation -->

	
<table class='news-layout'>
	<tr>
		<td class='news-icon'>
			<img src='../images/news/gdiac_logo.gif' class='image_shadow' alt='images/news/gdiac_logo.gif'/>
		</td>
		<td class='news-item'>
			<a name='news30' id='news30'></a>
<p class='news-header'>2020 Showcase Goes Online</p>

<p>
Despite the chaos of a somewhat online semester, our games have been going strong. 
In the past year 2019 favorite <a href="https://familystyle.info">Family Style</a> 
has been featured on the Apple App store and now has over 1.5 million downloads 
on all platforms.  It even has its own Reddit channel.
</p><p>
After much discussion, we have decided that COVID-19 will not stand in the way of
showcase. On Friday, May 22nd, we will make all of the games for this semester available 
for download from the official <a href="courses/showcase.php">Showcase page</a>.  But more
importantly, we will also issue temporary invites for everyone to join our Discord server.
This is open to the general public -- you do not need to be affiliated with Cornell.  
You can watch other people stream their games, stream yourself playing, or just get 
technical support if you are having trouble installing.
</p><p>
There are a lot of high quality games this year and we want them to have the same experience
that <i>Family Style</i> did last year -- getting the feedback that they need to push their
games to the next level. So come join us on May 22nd!
</p><p><b>Date/Time</b>: Friday, May 22nd from 1 -4 pm<br/><b>Venue</b>: Discord (Invite link on <a href="courses/showcase.php">Showcase page</a>)<br/></p></p>
				
		<p class='small'>Date Posted: May. 6, 2020 | <a href='http://gdiac.cis.cornell.edu/news/index.php?id=31'>Permalink</a><br /><br /></p>
		</td>
	</tr>
	<tr>
		<td class='news-icon'>
			<img src='../images/news/gdiac_logo.gif' class='image_shadow' alt='images/news/gdiac_logo.gif'/>
		</td>
		<td class='news-item'>
			<a name='news30' id='news30'></a>
<p class='news-header'>2019 Showcase Winners</p>

<p>
Congratulations to our Showcase Winners.  
</p><p><b>Audience Choice</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>Flourish</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>: <i>Family Style</i></li></ul><p><b>Most Polished Game</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>Starstruck</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>: <i>Pig Life Crisis</i></li></ul><p><b>Most Innovative Game</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>Prism Break</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>: <i>Family Style</i></li></ul>
				
		<p class='small'>Date Posted: May. 20, 2019 | <a href='http://gdiac.cis.cornell.edu/news/index.php?id=30'>Permalink</a><br /><br /></p>
		</td>
	</tr>
	<tr>
		<td class='news-icon'>
			<img src='../images/news/gdiac_logo.gif' class='image_shadow' alt='images/news/gdiac_logo.gif'/>
		</td>
		<td class='news-item'>
			<a name='news29' id='news29'></a>
<p class='news-header'>2019 GDIAC Showcase</p>

<p>
As the semester ends, it is time once again for the GDIAC showcase. The showcase will 
include student game projects from the past year.  We have a large number of exhibtions, 
including projects from CS/INFO 3152, CS/INFO 4152 and independent studies.
</p><p>
Last year was the 10th year that Walker White has directed the GDIAC program, and it was 
a great year. Once again, we placed several of our games at Boston FIG. The viral success 
of <i>Underhand</i> has continued, and it now has over a million downloads on Android. 
As Professor White enters his second decade running the program, we once again have a 
strong slate of games.
</p><p>
The showcase is open to the general public, so that everyone can play and experience
these projects.  In addition, the public is welcome to vote for the favorite in
the award ceremony at the end.  Come see what all of the excitement is about, and catch 
the next big game before it breaks out.
</p><p><b>Date/Time</b>: Friday, May 17th from 4 - 7 pm<br/><b>Venue</b>: ACCEL Labs in Carpenter Hall<br/></p></p>
				
		<p class='small'>Date Posted: May. 1, 2019 | <a href='http://gdiac.cis.cornell.edu/news/index.php?id=29'>Permalink</a><br /><br /></p>
		</td>
	</tr>
	<tr>
		<td class='news-icon'>
			<img src='../images/news/gdiac_logo.gif' class='image_shadow' alt='images/news/gdiac_logo.gif'/>
		</td>
		<td class='news-item'>
			<a name='news28' id='news28'></a>
<p class='news-header'>2018 Showcase Winners</p>

<p>
Congratulations to our Showcase Winners.  
</p><p><b>Audience Choice</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>Trino</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>: <i>Coalide</i></li></ul><p><b>Most Polished Game</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>ColorMari</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>: <i>Split</i></li></ul><p><b>Most Innovative Game</b>:</p><ul><li style="margin-top: 3pt"><b>Intro Division</b>: <i>OutOfSync</i></li><li style="margin-top: 3pt"><b>Mobile Division</b>:  <i>Arcane Tectonics</i></li></ul>
				
		<p class='small'>Date Posted: May. 22, 2018 | <a href='http://gdiac.cis.cornell.edu/news/index.php?id=28'>Permalink</a><br /><br /></p>
		</td>
	</tr>
	<tr>
		<td class='news-icon'>
			<img src='../images/news/gdiac_logo.gif' class='image_shadow' alt='images/news/gdiac_logo.gif'/>
		</td>
		<td class='news-item'>
			<a name='news27' id='news27'></a>
<p class='news-header'>2018 GDIAC Showcase</p>

<p>
As the semester ends, it is time once again for the GDIAC showcase. The showcase will 
include student game projects from the past year.  We have a large number of exhibtions, 
including projects from CS/INFO 3152, CS/INFO 4152 and independent studies.
</p><p>
Last year was an incredible year for mobile and smartphone games. <i>Manic Moving Mansion
Mania</i> won Best Student Game at Boston FIG.  <i>Underhand</i> went viral on Reddit and 
has over 600,000 downloads on Android.  But despite all that, this year looks even stronger.
We have rhythm games, puzzle games, action games, deep strategy games, and even 
experimental augmented reality games. There is something for everyone.
</p><p>
The showcase is open to the general public, so that everyone can play and experience
these projects.  In addition, the public is welcome to vote for the favorite in
the award ceremony at the end.  Come see what all of the excitement is about, and catch 
the next big game before it breaks out.
</p><p><b>Date/Time</b>: Friday, May 18th from 4 - 7 pm<br/><b>Venue</b>: ACCEL Labs in Carpenter Hall<br/></p></p>
				
		<p class='small'>Date Posted: Apr. 24, 2018 | <a href='http://gdiac.cis.cornell.edu/news/index.php?id=27'>Permalink</a><br /><br /></p>
		</td>
	</tr>
</table>
<p>page:  [1]  <a href="index.php?page=2">[2]</a>  <a href="index.php?page=3">[3]</a>  <a href="index.php?page=4">[4]</a>  <a href="index.php?page=5">[5]</a>  <a href="index.php?page=6">[6]</a>  <a href="index.php?page=7">[7]</a> </p>

	<!-- Start of Close Bracket for Navigation -->
						</div>
					</td></tr>
                </table>
            </td></tr>
		</table>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center" class="footer">
	<tr>
	<td align="left">
			<a href="http://www.cis.cornell.edu">Computing and Information Science</a> &raquo; 
			<a href="http://gdiac.cis.cornell.edu">Game Design Initiative</a> 
	</td>
	<td align="right">
			<a href='../about/contact.php'>Contact Us</a> | 
			<a href="http://www.cs.cornell.edu/feedback/feedback.aspx">Feedback</a> </td>
	</tr>
</table>        
<!-- End of Close Bracket for Navigation -->
    </div>
</body>
</html>